import cv2
import os

# Nombre de la carpeta donde se guardarán las imágenes
output_folder = "fotos_laterales_cilindro"
os.makedirs(output_folder, exist_ok=True)

# Inicializar la cámara (0 es la cámara predeterminada)
cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print("Error: No se pudo abrir la cámara.")
    exit()

# Contador de imágenes
img_counter = 0

while True:
    ret, frame = cap.read()
    if not ret:
        print("Error: No se pudo capturar la imagen.")
        break

    # Mostrar la imagen en una ventana
    cv2.imshow("Captura de imágenes", frame)

    # Esperar por una tecla
    key = cv2.waitKey(1) & 0xFF

    if key == ord('s'):  # Guardar imagen con 's'
        img_name = os.path.join(output_folder, f"imagen_{img_counter}.jpg")
        cv2.imwrite(img_name, frame)
        print(f"Imagen guardada: {img_name}")
        img_counter += 1

    elif key == ord('q'):  # Salir con 'q'
        break

# Liberar recursos
cap.release()
cv2.destroyAllWindows()
