import cv2
import numpy as np
import math

# Cargar la imagen
image = cv2.imread("fotos_setcamara/imagen_27.jpg")  # Cambia el nombre según tu imagen
clone = image.copy()
roi = None

# Escala de conversión
factor_conversion = 133 / 288 #  mm/px

# Lista para almacenar diámetros detectados
detected_circles = []

# Función para seleccionar el área de interés (ROI)
def select_roi(event, x, y, flags, param):
    global roi
    if event == cv2.EVENT_LBUTTONDOWN:
        roi = [(x, y)]
    elif event == cv2.EVENT_LBUTTONUP:
        roi.append((x, y))
        cv2.rectangle(clone, roi[0], roi[1], (0, 255, 0), 2)
        cv2.imshow("Imagen", clone)

# Mostrar la imagen y capturar ROI
cv2.imshow("Imagen", image)
cv2.setMouseCallback("Imagen", select_roi)
cv2.waitKey(0)
cv2.destroyAllWindows()

# Recortar la imagen si el ROI fue seleccionado
if roi and len(roi) == 2:
    x1, y1 = roi[0]
    x2, y2 = roi[1]
    cropped_image = image[y1:y2, x1:x2]
else:
    cropped_image = image.copy()

# Convertir a escala de grises
gray = cv2.cvtColor(cropped_image, cv2.COLOR_BGR2GRAY)

# Aplicar un filtro Gaussiano para reducir ruido
gray_blurred = cv2.GaussianBlur(gray, (5, 5), 0)

# Aplicar detección de bordes con Canny
edges = cv2.Canny(gray_blurred, 30, 120)

kernel = np.ones((5, 5), np.uint8)  # Kernel de 5x5, puedes probar con (3,3) o (7,7)
# **Opcional: Aplicar cierre morfológico para cerrar huecos en los contornos**
edges = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, kernel)


# **Aplicar dilatación para unir contornos rotos**
kernel = np.ones((5, 5), np.uint8)  # Kernel de 5x5, puedes probar con (3,3) o (7,7)
dilated_edges = cv2.dilate(edges, kernel, iterations=1)  # Iteraciones aumentan la dilatación

# Encontrar contornos en la imagen dilatada
contours_dil, _ = cv2.findContours(dilated_edges, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

# Encontrar todos los contornos
contours, _ = cv2.findContours(edges, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)  # Detecta todos los contornos

# **1. Detectar el contorno exterior más grande (perímetro)**

# **Ordenar los contornos por área de mayor a menor**
contours_dil = sorted(contours_dil, key=cv2.contourArea, reverse=True)

if len(contours_dil) > 1:
    # Contorno más grande
    largest_contour = contours_dil[0]
    perimeter_px_1 = cv2.arcLength(largest_contour, True)
    perimeter_mm_1 = round(perimeter_px_1 * factor_conversion, 2)

    # Contorno segundo más grande
    second_largest_contour = contours_dil[1]
    perimeter_px_2 = cv2.arcLength(second_largest_contour, True)
    perimeter_mm_2 = round(perimeter_px_2 * factor_conversion, 2)

    # Contorno segundo más grande
    third_largest_contour = contours_dil[2]
    perimeter_px_3 = cv2.arcLength(third_largest_contour, True)
    perimeter_mm_3 = round(perimeter_px_3 * factor_conversion, 2)


    # Dibujar los contornos en la imagen
    cv2.drawContours(cropped_image, [largest_contour], -1, (255, 0, 255), 2)  # Morado para el más grande
    cv2.drawContours(cropped_image, [second_largest_contour], -1, (255, 255, 0), 2)  # Azul para el segundo más grande
    cv2.drawContours(cropped_image, [third_largest_contour], -1, (255, 105, 180), 2)  # rosa para el tercer más grande


    # Mostrar las medidas en la imagen
    x1, y1, _, _ = cv2.boundingRect(largest_contour)
    x2, y2, _, _ = cv2.boundingRect(second_largest_contour)
    x3, y3, _, _ = cv2.boundingRect(third_largest_contour)

    cv2.putText(cropped_image, f"Perimetro 1: {perimeter_mm_1} mm", (x1 + 10, y1 + 15),
                cv2.FONT_HERSHEY_SIMPLEX, 0.3, (255, 255, 255), 1)

    cv2.putText(cropped_image, f"Perimetro 2: {perimeter_mm_2} mm", (x2 + 10, y2 + 20),
                cv2.FONT_HERSHEY_SIMPLEX, 0.3, (255, 255, 255), 1)
    
    cv2.putText(cropped_image, f"Perimetro 3: {perimeter_mm_3} mm", (x3 + 10, y3 + 20),
                cv2.FONT_HERSHEY_SIMPLEX, 0.3, (255, 255, 255), 1)




# **2. Detectar los círculos internos dentro del objeto**
min_distance = 20
circle_centers = []

for cnt in contours:
    area = cv2.contourArea(cnt)
    perimeter = cv2.arcLength(cnt, True)
    
    if perimeter == 0 or np.array_equal(cnt, largest_contour):  # Ignorar el contorno exterior
        continue
    
    circularity = 4 * np.pi * (area / (perimeter ** 2))
    
    if 0.7 < circularity < 1.2 and 10 < area < 5000:
        (x, y), radius = cv2.minEnclosingCircle(cnt)
        
        # Convertir valores a enteros
        center = (int(x), int(y))
        radius = int(round(radius))  # Redondear antes de convertir
        
        # Evitar duplicados con min_distance
        if all(np.linalg.norm(np.array(center) - np.array(c)) > min_distance for c in circle_centers):
            circle_centers.append(center)
            cv2.circle(cropped_image, center, radius, (0, 255, 0), 2)  # Dibujar en verde
            
           # Calcular el diámetro en píxeles y mm
            diameter_px = int(2 * radius)  # Redondear antes de convertir a int
            diameter_mm = int(round(diameter_px * factor_conversion))


            # Guardar en la lista
            detected_circles.append((diameter_px, diameter_mm))

            # Mostrar el tamaño real en la imagen
            cv2.putText(cropped_image, f"{diameter_mm} mm", (center[0] - 20, center[1] - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.3, (255, 255, 255), 1)
            
# Detección de círculos con HoughCircles
circles = cv2.HoughCircles(gray_blurred, cv2.HOUGH_GRADIENT, dp=1.2, minDist=min_distance,
                           param1=50, param2=45, minRadius=10, maxRadius=30)

if circles is not None:
    circles = np.uint16(np.around(circles[0]))  # Corregir indexación
    for circle in circles:
        x, y, radius = map(int, circle)  # Convertir cada valor a int

        center = (x, y)
        radius = int(round(radius))  # Redondear antes de convertir a int
        
        if all(np.linalg.norm(np.array(center) - np.array(c)) > min_distance for c in circle_centers):
            circle_centers.append(center)
            cv2.circle(cropped_image, center, radius, (0, 0, 255), 2)

            # Calcular el diámetro en píxeles y mm
            diameter_px = int(2 * radius)  # Redondear antes de convertir a int
            diameter_mm = int(round(diameter_px * factor_conversion))

            # Guardar en la lista
            detected_circles.append((diameter_px, diameter_mm))

            # Mostrar el tamaño real en la imagen
            cv2.putText(cropped_image, f"{diameter_mm} mm", (center[0] - 20, center[1] - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

# Identificar el círculo más a la izquierda y el más a la derecha
if circle_centers:
    leftmost_circle = min(circle_centers, key=lambda c: c[0])  # Menor valor de x
    rightmost_circle = max(circle_centers, key=lambda c: c[0])  # Mayor valor de x

    print(f"\nCírculo más a la izquierda: (x: {leftmost_circle[0]}, y: {leftmost_circle[1]})")
    print(f"Círculo más a la derecha: (x: {rightmost_circle[0]}, y: {rightmost_circle[1]})")
else:
    print("\nNo se detectaron círculos.")


# Calcular la distancia en píxeles
distance_px = math.sqrt((rightmost_circle[0] - leftmost_circle[0])**2 + 
                        (rightmost_circle[1] - leftmost_circle[1])**2)

# Convertir la distancia a milímetros
distance_mm = round(distance_px * factor_conversion, 2)

print(f"\nDistancia entre el círculo más a la izquierda y el más a la derecha: {distance_px:.2f} px ({distance_mm} mm)")

# Dibujar una línea entre los dos círculos
# Parámetros para la línea punteada
seg_length = 10  # Longitud de cada segmento
gap = 5  # Espaciado entre segmentos
line_color = (126, 238, 14)  # Verde turquesa detectado

# Obtener coordenadas de los círculos
x1, y1 = leftmost_circle
x2, y2 = rightmost_circle
dist_px = int(math.dist(leftmost_circle, rightmost_circle))
dist_mm = round(dist_px * factor_conversion, 2)  # Convertir a mm

# Dibujar la línea punteada
for i in range(0, dist_px, seg_length + gap):
    t1, t2 = i / dist_px, min((i + seg_length) / dist_px, 1)
    p1 = (int(x1 + (x2 - x1) * t1), int(y1 + (y2 - y1) * t1))
    p2 = (int(x1 + (x2 - x1) * t2), int(y1 + (y2 - y1) * t2))
    cv2.line(cropped_image, p1, p2, line_color, 2)  # Línea punteada en verde turquesa

# Calcular la posición para el texto (cerca del centro de la línea)
text_x, text_y = (x1 + x2) // 2, (y1 + y2) // 2 - 10  # Un poco arriba del centro

# Agregar el texto con la distancia en mm
cv2.putText(cropped_image, f"Distancia entre circulos: {dist_mm} mm", (text_x-40, text_y+80), 
            cv2.FONT_HERSHEY_SIMPLEX, 0.3, (255, 255, 255), 1)


# Mostrar imágenes
cv2.imshow("Contorno Exterior y Circulos Detectados", cropped_image)
cv2.imshow("Bordes Detectados", dilated_edges)
cv2.waitKey(0)
cv2.destroyAllWindows()

# Imprimir los diámetros detectados y el perímetro al final
print("\nDiámetros detectados:")
for i, (diam_px, diam_mm) in enumerate(detected_circles):
    print(f"Círculo {i + 1}: {diam_px} px ({diam_mm} mm)")


# Imprimir los perímetros en consola
print(f"\nPerímetro 1 (más grande): {perimeter_px_1:.2f} px ({perimeter_mm_1} mm)")
print(f"Perímetro 2 (segundo más grande): {perimeter_px_2:.2f} px ({perimeter_mm_2} mm)")
print(f"Perímetro 3 (tercer más grande): {perimeter_px_3:.2f} px ({perimeter_mm_3} mm)")

# Imprimir las coordenadas de los centros de los círculos detectados
print("\nCoordenadas de los centros de los círculos detectados:")
for i, center in enumerate(circle_centers):
    print(f"Círculo {i + 1}: (x: {center[0]}, y: {center[1]})")
