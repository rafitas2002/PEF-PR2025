import cv2
import numpy as np
import math


# Cargar la imagen
image = cv2.imread("fotos_protesis/imagen_8.jpg")  # Cambia el nombre según tu imagen
clone = image.copy()
roi = None

# Escala de conversión
factor_conversion = 27 / 60  # mm/px

# Lista para almacenar diámetros detectados
detected_circles = []

# Función para redondear a .5 o entero
def round_half_up(n):
    return round(n * 2) / 2  # Redondear al número entero o .5 más cercano

# Función para seleccionar el área de interés (ROI)
def select_roi(event, x, y, flags, param):
    global roi
    if event == cv2.EVENT_LBUTTONDOWN:
        roi = [(x, y)]
    elif event == cv2.EVENT_LBUTTONUP:
        roi.append((x, y))
        cv2.rectangle(clone, roi[0], roi[1], (0, 255, 0), 2)
        cv2.imshow("Imagen", clone)

# Mostrar la imagen y capturar ROI
cv2.imshow("Imagen", image)
cv2.setMouseCallback("Imagen", select_roi)
cv2.waitKey(0)
cv2.destroyAllWindows()

# Recortar la imagen si el ROI fue seleccionado
if roi and len(roi) == 2:
    x1, y1 = roi[0]
    x2, y2 = roi[1]
    cropped_image = image[y1:y2, x1:x2]
else:
    cropped_image = image.copy()

# Convertir a escala de grises
gray = cv2.cvtColor(cropped_image, cv2.COLOR_BGR2GRAY)

# Aplicar un filtro Gaussiano para reducir ruido
gray_blurred = cv2.GaussianBlur(gray, (5, 5), 0)

# Aplicar detección de bordes con Canny
edges = cv2.Canny(gray_blurred, 30, 90)

# Encontrar todos los contornos
contours, _ = cv2.findContours(edges, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)  # Detecta todos los contornos

# **1. Detectar el contorno exterior más grande (perímetro)**
if contours:
    largest_contour = max(contours, key=cv2.contourArea)  # Encontrar el contorno más grande
    perimeter_px = cv2.arcLength(largest_contour, True)  # Perímetro en píxeles
    perimeter_mm = round_half_up(perimeter_px * factor_conversion)  # Convertir a mm

    # Dibujar el contorno exterior en morado
    cv2.drawContours(cropped_image, [largest_contour], -1, (255, 0, 255), 2)

    # Mostrar la medida del perímetro en la imagen
    x, y, w, h = cv2.boundingRect(largest_contour)  # Obtener una caja alrededor del objeto
    cv2.putText(cropped_image, f"Perimetro: {perimeter_mm} mm", (x+10, y + 20),
                cv2.FONT_HERSHEY_SIMPLEX, 0.3, (255, 255, 255), 1)

# **2. Detectar los círculos internos dentro del objeto**
min_distance = 10
circle_centers = []

for cnt in contours:
    area = cv2.contourArea(cnt)
    perimeter = cv2.arcLength(cnt, True)
    
    if perimeter == 0 or np.array_equal(cnt, largest_contour):  # Ignorar el contorno exterior
        continue
    
    circularity = 4 * np.pi * (area / (perimeter ** 2))
    
    if 0.7 < circularity < 1.2 and 10 < area < 5000:
        (x, y), radius = cv2.minEnclosingCircle(cnt)
        
        # Convertir valores a enteros
        center = (int(x), int(y))
        radius = int(round(radius))  # Redondear antes de convertir
        
        # Evitar duplicados con min_distance
        if all(np.linalg.norm(np.array(center) - np.array(c)) > min_distance for c in circle_centers):
            circle_centers.append(center)
            cv2.circle(cropped_image, center, radius, (0, 255, 0), 2)  # Dibujar en verde
            
            # Calcular el diámetro en píxeles y mm
            diameter_px = int(2 * radius)  
            diameter_mm = round_half_up(diameter_px * factor_conversion)  # Redondear a .5 o entero

            # Guardar en la lista
            detected_circles.append((diameter_px, diameter_mm, center))


            # Mostrar el tamaño real en la imagen
            cv2.putText(cropped_image, f"{diameter_mm} mm", (center[0] - 20, center[1] - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.3, (255, 255, 255), 1)

# Ordenar los círculos por diámetro de mayor a menor
detected_circles.sort(reverse=True, key=lambda c: c[0])  # Ordenar por diámetro en px

# Verificar si hay al menos dos círculos detectados
if len(detected_circles) >= 2:
    # Seleccionar los dos círculos más grandes
    largest_circle = detected_circles[0]  # Círculo más grande
    second_largest_circle = detected_circles[1]  # Segundo más grande

    # Obtener coordenadas de los centros
    (x1, y1) = largest_circle[2]
    (x2, y2) = second_largest_circle[2]

    # Calcular la distancia en píxeles
    distance_px = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
    distance_mm = round(distance_px * factor_conversion, 2)

    print(f"\nDistancia entre los dos círculos más grandes: {distance_px:.2f} px ({distance_mm} mm)")

    # Dibujar una línea punteada entre los dos círculos más grandes
    seg_length = 10  # Longitud de cada segmento de línea
    gap = 5  # Espaciado entre segmentos
    line_color = (255, 105, 180)  # Color moradito

    # Calcular la distancia entre los puntos
    dist_px = int(math.dist((x1, y1), (x2, y2)))

    # Dibujar segmentos de línea punteada
    for i in range(0, dist_px, seg_length + gap):
        t1, t2 = i / dist_px, min((i + seg_length) / dist_px, 1)
        p1 = (int(x1 + (x2 - x1) * t1), int(y1 + (y2 - y1) * t1))
        p2 = (int(x1 + (x2 - x1) * t2), int(y1 + (y2 - y1) * t2))
        cv2.line(cropped_image, p1, p2, line_color, 2)  # Línea punteada en verde turquesa

    # Agregar el texto con la distancia
    text_x, text_y = (x1 + x2) // 2, (y1 + y2) // 2 - 10
    cv2.putText(cropped_image, f"Distancia entre circulos: {distance_mm} mm", (text_x - 80, text_y + 60),
                cv2.FONT_HERSHEY_SIMPLEX, 0.3, (255, 255, 255), 1)


else:
    print("\nNo se detectaron suficientes círculos grandes.")

# Mostrar imágenes
cv2.imshow("Contorno Exterior y Circulos Detectados", cropped_image)
cv2.waitKey(0)
cv2.destroyAllWindows()

# Imprimir los diámetros detectados y el perímetro al final
print("\nDiámetros detectados:")
for i, (diam_px, diam_mm, center) in enumerate(detected_circles):
    print(f"Círculo {i + 1}: {diam_px} px ({diam_mm} mm)")

print(f"\nPerímetro exterior: {perimeter_px:.2f} px ({perimeter_mm} mm)")
