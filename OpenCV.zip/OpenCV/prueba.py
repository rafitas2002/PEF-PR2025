import cv2
import numpy as np
import json
import os
from collections import Counter

# Factores
factor_conversion = 41 / 78  # mm/px
roi_file = "roi_cilindro_lateral.json"

# Funciones para análisis
def es_horizontal(x1, y1, x2, y2, umbral_angulo=10):
    angle = np.degrees(np.arctan2(y2 - y1, x2 - x1))
    return abs(angle) < umbral_angulo or abs(angle) > (180 - umbral_angulo)

def es_vertical(x1, y1, x2, y2, umbral_angulo=10):
    angle = np.degrees(np.arctan2(y2 - y1, x2 - x1))
    return abs(abs(angle) - 90) < umbral_angulo

def unir_lineas_similares(lineas, es_tipo, distancia_umbral=2):
    grupos = []
    for l in lineas:
        x1, y1, x2, y2 = l
        agregado = False
        for grupo in grupos:
            for g in grupo:
                if es_tipo(x1, y1, x2, y2) and (
                    np.linalg.norm([x1 - g[0], y1 - g[1]]) < distancia_umbral or
                    np.linalg.norm([x2 - g[2], y2 - g[3]]) < distancia_umbral
                ):
                    grupo.append((x1, y1, x2, y2))
                    agregado = True
                    break
            if agregado:
                break
        if not agregado:
            grupos.append([(x1, y1, x2, y2)])
    lineas_unidas = []
    for grupo in grupos:
        xs = [x1 for x1, _, x2, _ in grupo] + [x2 for _, _, x2, _ in grupo]
        ys = [y1 for _, y1, _, y2 in grupo] + [y2 for _, _, _, y2 in grupo]
        if es_tipo == es_horizontal:
            y_prom = int(np.mean(ys))
            lineas_unidas.append((min(xs), y_prom, max(xs), y_prom))
        else:
            x_prom = int(np.mean(xs))
            lineas_unidas.append((x_prom, min(ys), x_prom, max(ys)))
    return lineas_unidas

def eliminar_lineas_duplicadas(lineas, umbral=15, es_tipo=None):
    finales = []
    for l in lineas:
        x1, y1, x2, y2 = l
        duplicada = False
        for lx1, ly1, lx2, ly2 in finales:
            if es_tipo == es_horizontal:
                misma_altura = abs(y1 - ly1) < umbral and abs(y2 - ly2) < umbral
                solapamiento = not (x2 < lx1 or x1 > lx2)
                if misma_altura and solapamiento:
                    duplicada = True
                    break
            elif es_tipo == es_vertical:
                misma_columna = abs(x1 - lx1) < umbral and abs(x2 - lx2) < umbral
                solapamiento = not (y2 < ly1 or y1 > ly2)
                if misma_columna and solapamiento:
                    duplicada = True
                    break
        if not duplicada:
            finales.append(l)
    return finales

# Leer ROI si ya existe
if os.path.exists(roi_file):
    with open(roi_file, "r") as f:
        roi = json.load(f)
else:
    # Capturar imagen para seleccionar ROI
    cap = cv2.VideoCapture(2)
    if not cap.isOpened():
        print("No se pudo acceder a la cámara.")
        exit()
    ret, frame = cap.read()
    cap.release()
    if not ret:
        print("No se pudo capturar imagen para ROI.")
        exit()

    image = frame.copy()
    clone = image.copy()
    roi = []

    def select_roi(event, x, y, flags, param):
        global roi
        if event == cv2.EVENT_LBUTTONDOWN:
            roi = [(x, y)]
        elif event == cv2.EVENT_LBUTTONUP:
            roi.append((x, y))
            cv2.rectangle(clone, roi[0], roi[1], (0, 255, 0), 2)
            cv2.imshow("Selecciona ROI", clone)

    cv2.imshow("Selecciona ROI", image)
    cv2.setMouseCallback("Selecciona ROI", select_roi)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

    if len(roi) != 2:
        print("ROI inválido.")
        exit()

    with open(roi_file, "w") as f:
        json.dump(roi, f)

x1, y1 = roi[0]
x2, y2 = roi[1]

# Comenzar análisis de 10 imágenes
cap = cv2.VideoCapture(2)
if not cap.isOpened():
    print("No se pudo abrir la cámara.")
    exit()

# Repetir análisis 10 veces
for i in range(10):
    ret, frame = cap.read()
    if not ret:
        print(f"No se pudo capturar la imagen {i+1}")
        continue

    image = frame.copy()
    cropped = image[min(y1,y2):max(y1,y2), min(x1,x2):max(x1,x2)]

    gray = cv2.cvtColor(cropped, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (7, 7), 0)
    edges = cv2.Canny(blurred, 30, 100)

    lineas = cv2.HoughLinesP(edges, 1, np.pi / 180, threshold=7, minLineLength=10, maxLineGap=15)
    height, width = cropped.shape[:2]
    border_margin = 10

    horizontales = []
    verticales = []

    if lineas is not None:
        for line in lineas:
            x1_, y1_, x2_, y2_ = line[0]
            if min(x1_, x2_) < border_margin or max(x1_, x2_) > width - border_margin:
                continue
            if min(y1_, y2_) < border_margin or max(y1_, y2_) > height - border_margin:
                continue
            if es_horizontal(x1_, y1_, x2_, y2_):
                horizontales.append((x1_, y1_, x2_, y2_))
            elif es_vertical(x1_, y1_, x2_, y2_):
                verticales.append((x1_, y1_, x2_, y2_))

    # Unir y eliminar duplicadas
    lineas_horizontales = unir_lineas_similares(horizontales, es_horizontal)
    lineas_horizontales = eliminar_lineas_duplicadas(lineas_horizontales, umbral=5, es_tipo=es_horizontal)

    lineas_verticales = unir_lineas_similares(verticales, es_vertical)
    lineas_verticales = eliminar_lineas_duplicadas(lineas_verticales, umbral=5, es_tipo=es_vertical)

    lineas_horizontales = sorted(lineas_horizontales, key=lambda l: l[1])[:2]
    lineas_verticales = sorted(lineas_verticales, key=lambda l: l[0])[:4]

    resultado = cropped.copy()
    for x1_, y1_, x2_, y2_ in lineas_horizontales + lineas_verticales:
        cv2.line(resultado, (x1_, y1_), (x2_, y2_), (0, 255, 0), 2)

    if len(lineas_horizontales) == 2:
        y_top = lineas_horizontales[0][1]
        y_bottom = lineas_horizontales[1][1]
        distancia_px = abs(y_bottom - y_top)
        distancia_mm = distancia_px * factor_conversion

        print(f"\n[{i+1}/10] 📐 Distancia entre líneas horizontales más alta y más baja:")
        print(f"   {distancia_px:.2f} px | {distancia_mm:.2f} mm")

        x_ref = int((lineas_horizontales[0][0] + lineas_horizontales[0][2]) / 2)
        cv2.line(resultado, (x_ref, y_top), (x_ref, y_bottom), (0, 0, 255), 2)
        cv2.putText(resultado, f"{distancia_mm:.1f} mm", (x_ref + 5, int((y_top + y_bottom)/2)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 255), 1)

    todas_las_lineas = lineas_horizontales + lineas_verticales
    print(f"\n🔍 Total de líneas detectadas en imagen {i+1}: {len(todas_las_lineas)}")
    print("📏 Longitudes de líneas:")

    for j, (x1_, y1_, x2_, y2_) in enumerate(todas_las_lineas, start=1):
        longitud_px = np.linalg.norm([x2_ - x1_, y2_ - y1_])
        longitud_mm = longitud_px * factor_conversion
        print(f"  Línea {j}: ({x1_}, {y1_}) -> ({x2_}, {y2_}) | {longitud_px:.2f} px | {longitud_mm:.2f} mm")

    if len(todas_las_lineas) >= 3:
        x1_, y1_, x2_, y2_ = todas_las_lineas[2]
        longitud_mm = np.linalg.norm([x2_ - x1_, y2_ - y1_]) * factor_conversion
        cv2.line(resultado, (x1_, y1_), (x2_, y2_), (0, 140, 255), 2)
        mid_x = int((x1_ + x2_) / 2)
        mid_y = int((y1_ + y2_) / 2)
        cv2.putText(resultado, f"{longitud_mm:.1f} mm", (mid_x + 5, mid_y),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 140, 255), 1)

    if len(todas_las_lineas) >= 4:
        x1_, y1_, x2_, y2_ = todas_las_lineas[3]
        longitud_mm = np.linalg.norm([x2_ - x1_, y2_ - y1_]) * factor_conversion
        cv2.line(resultado, (x1_, y1_), (x2_, y2_), (255, 0, 0), 2)
        mid_x = int((x1_ + x2_) / 2)
        mid_y = int((y1_ + y2_) / 2)
        cv2.putText(resultado, f"{longitud_mm:.1f} mm", (mid_x + 5, mid_y),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 0, 0), 1)

    if len(todas_las_lineas) >= 5:
        mid_4 = np.mean([(todas_las_lineas[3][0], todas_las_lineas[3][1]), (todas_las_lineas[3][2], todas_las_lineas[3][3])], axis=0)
        mid_5 = np.mean([(todas_las_lineas[4][0], todas_las_lineas[4][1]), (todas_las_lineas[4][2], todas_las_lineas[4][3])], axis=0)

        dist_px = np.linalg.norm(mid_5 - mid_4)
        dist_mm = dist_px * factor_conversion

        print(f"\n🔵 Distancia entre línea 4 y línea 5:")
        print(f"   {dist_px:.2f} px | {dist_mm:.2f} mm")

        punto1 = tuple(map(int, mid_4))
        punto2 = tuple(map(int, mid_5))
        cv2.line(resultado, punto1, punto2, (200, 0, 200), 2)
        pos_texto = (int((punto1[0] + punto2[0]) / 2 + 5), int((punto1[1] + punto2[1]) / 2-17))
        cv2.putText(resultado, f"{dist_mm:.1f} mm", pos_texto, cv2.FONT_HERSHEY_SIMPLEX, 0.4, (200, 0, 200), 1)

    # Inicializar listas para guardar mediciones
    dist_horizontales = []
    dist_l4_l5 = []
    len_linea4 = []
    len_linea3 = []
    resultados = []

    # Dentro del for i in range(10): — después de calcular cada medida
    # Agrega este bloque después de calcular cada una:

    if len(lineas_horizontales) == 2:
        dist_horizontales.append(distancia_mm)
    else:
        dist_horizontales.append(None)

    if len(todas_las_lineas) >= 5:
        dist_l4_l5.append(dist_mm)
    else:
        dist_l4_l5.append(None)

    if len(todas_las_lineas) >= 4:
        longitud_linea4_mm = np.linalg.norm([todas_las_lineas[3][2] - todas_las_lineas[3][0],
                                            todas_las_lineas[3][3] - todas_las_lineas[3][1]]) * factor_conversion
        len_linea4.append(longitud_linea4_mm)
    else:
        len_linea4.append(None)

    if len(todas_las_lineas) >= 3:
        longitud_linea3_mm = np.linalg.norm([todas_las_lineas[2][2] - todas_las_lineas[2][0],
                                            todas_las_lineas[2][3] - todas_las_lineas[2][1]]) * factor_conversion
        len_linea3.append(longitud_linea3_mm)
    else:
        len_linea3.append(None)

    # Verificación por rangos
    def en_rango(valor, minimo, maximo):
        return valor is not None and minimo <= valor <= maximo

    r1 = en_rango(dist_horizontales[-1], 38, 43)
    r2 = en_rango(dist_l4_l5[-1], 17, 23)
    r3 = en_rango(len_linea4[-1], 12, 16)
    r4 = en_rango(len_linea3[-1], 24, 30)

    es_valida = r1 and r2 and r3 and r4
    resultados.append("Valida" if es_valida else "No Valida")

    # Mostrar resultado individual
    print(f"\n✅ Resultado imagen {i+1}: {'Valida' if es_valida else 'No Valida'}")

    cv2.imshow(f"Resultado {i+1}/10", resultado)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


# Al terminar las 10 imágenes (después del for)
if i == 9:
    resultado_final = Counter(resultados).most_common(1)[0][0]
    print("\n📊 RESULTADO FINAL POR MODA:")
    print(f"👉 La pieza es: **{resultado_final}**")

cap.release()




