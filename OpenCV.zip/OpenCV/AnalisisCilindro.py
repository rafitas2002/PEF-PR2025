import cv2
import numpy as np

# Cargar la imagen
image = cv2.imread("fotos_setcamara/imagen_58.jpg")  # Cambia el nombre según tu imagen
clone = image.copy()
roi = None

# Escala de conversión
factor_conversion = 30 / 60  #  mm/px

# Lista para almacenar diámetros detectados
detected_circles = []

# Función para seleccionar el área de interés (ROI)
def select_roi(event, x, y, flags, param):
    global roi
    if event == cv2.EVENT_LBUTTONDOWN:
        roi = [(x, y)]
    elif event == cv2.EVENT_LBUTTONUP:
        roi.append((x, y))
        cv2.rectangle(clone, roi[0], roi[1], (0, 255, 0), 2)
        cv2.imshow("Imagen", clone)

# Mostrar la imagen y capturar ROI
cv2.imshow("Imagen", image)
cv2.setMouseCallback("Imagen", select_roi)
cv2.waitKey(0)
cv2.destroyAllWindows()

# Recortar la imagen si el ROI fue seleccionado
if roi and len(roi) == 2:
    x1, y1 = roi[0]
    x2, y2 = roi[1]
    cropped_image = image[y1:y2, x1:x2]
else:
    cropped_image = image.copy()

# Convertir a escala de grises
gray = cv2.cvtColor(cropped_image, cv2.COLOR_BGR2GRAY)

# Aplicar un filtro Gaussiano para reducir ruido
gray_blurred = cv2.GaussianBlur(gray, (5, 5), 0)

# Aplicar detección de bordes con Canny
edges = cv2.Canny(gray_blurred, 30, 120)

# Encontrar contornos
contours, _ = cv2.findContours(edges, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

# Dibujar los contornos en la imagen
image_contours = cropped_image.copy()
cv2.drawContours(image_contours, contours, -1, (0, 255, 0), 2)

# Variable para evitar duplicados
min_distance = 20  
circle_centers = []

# Detección de círculos con contornos
for cnt in contours:
    area = cv2.contourArea(cnt)
    perimeter = cv2.arcLength(cnt, True)
    
    if perimeter == 0:
        continue
    
    circularity = 4 * np.pi * (area / (perimeter ** 2))
    
    if 0.7 < circularity < 1.2 and 30 < area < 5000:
        (x, y), radius = cv2.minEnclosingCircle(cnt)
        
        # Convertir valores a enteros
        center = (int(x), int(y))
        radius = int(round(radius))  # Redondear antes de convertir
        
        # Evitar duplicados con min_distance
        if all(np.linalg.norm(np.array(center) - np.array(c)) > min_distance for c in circle_centers):
            circle_centers.append(center)
            cv2.circle(cropped_image, center, radius, (0, 255, 0), 2)
            
            # Calcular el diámetro en píxeles y mm
            diameter_px = int(2 * radius)  # Redondear antes de convertir a int
            diameter_mm = int(round(diameter_px * factor_conversion))

            # Guardar en la lista
            detected_circles.append((diameter_px, diameter_mm))

            # Mostrar el tamaño real en la imagen
            cv2.putText(cropped_image, f"{diameter_mm} mm", (center[0] - 20, center[1] - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

# Detección de círculos con HoughCircles
circles = cv2.HoughCircles(gray_blurred, cv2.HOUGH_GRADIENT, dp=1.2, minDist=min_distance,
                           param1=50, param2=45, minRadius=10, maxRadius=30)

if circles is not None:
    circles = np.uint16(np.around(circles[0]))  # Corregir indexación
    for circle in circles:
        x, y, radius = map(int, circle)  # Convertir cada valor a int

        center = (x, y)
        radius = int(round(radius))  # Redondear antes de convertir a int
        
        if all(np.linalg.norm(np.array(center) - np.array(c)) > min_distance for c in circle_centers):
            circle_centers.append(center)
            cv2.circle(cropped_image, center, radius, (0, 0, 255), 2)

            # Calcular el diámetro en píxeles y mm
            diameter_px = int(2 * radius)  # Redondear antes de convertir a int
            diameter_mm = int(round(diameter_px * factor_conversion))

            # Guardar en la lista
            detected_circles.append((diameter_px, diameter_mm))

            # Mostrar el tamaño real en la imagen
            cv2.putText(cropped_image, f"{diameter_mm} mm", (center[0] - 20, center[1] - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

# Mostrar imágenes
cv2.imshow("Circulos Detectados con Medidas", cropped_image)
cv2.waitKey(0)
cv2.destroyAllWindows()

# Imprimir los diámetros detectados al final
print("\nDiametros detectados:")
for i, (diam_px, diam_mm) in enumerate(detected_circles):
    print(f"Círculo {i + 1}: {diam_px} px ({diam_mm} mm)")
