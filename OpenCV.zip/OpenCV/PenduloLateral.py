import cv2
import numpy as np
import json
import os

# Cargar imagen
image = cv2.imread("fotos_laterales_final/imagen_0.jpg")
clone = image.copy()
roi = None
roi_file = "roi_lat_pen.json"
factor_conversion = 20 / 46  # mm/px

# Intentar cargar ROI guardado
if os.path.exists(roi_file):
    with open(roi_file, "r") as f:
        roi = json.load(f)
        print(f"ROI cargado: {roi}")
        x1, y1 = roi[0]
        x2, y2 = roi[1]
else:
    # Seleccionar ROI manualmente
    def select_roi(event, x, y, flags, param):
        global roi
        if event == cv2.EVENT_LBUTTONDOWN:
            roi = [(x, y)]
        elif event == cv2.EVENT_LBUTTONUP:
            roi.append((x, y))
            cv2.rectangle(clone, roi[0], roi[1], (0, 255, 0), 2)
            cv2.imshow("Imagen", clone)

    print("Selecciona un ROI (clic y arrastra)")
    cv2.imshow("Imagen", image)
    cv2.setMouseCallback("Imagen", select_roi)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

    # Guardar ROI
    if roi and len(roi) == 2:
        with open(roi_file, "w") as f:
            json.dump(roi, f)
            print(f"ROI guardado en {roi_file}")
        x1, y1 = roi[0]
        x2, y2 = roi[1]
    else:
        print("No se seleccionó un ROI válido.")
        exit()

# Aplicar ROI
cropped_image = image[y1:y2, x1:x2]

# Preprocesamiento de la imagen recortada
gray = cv2.cvtColor(cropped_image, cv2.COLOR_BGR2GRAY)
blurred = cv2.GaussianBlur(gray, (5, 5), 0)
edges = cv2.Canny(blurred, 50, 150)

# Encontrar contornos
contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)

# Filtrar y ordenar curvas por longitud
curves = [(cv2.arcLength(c, False), c) for c in contours if cv2.arcLength(c, False) > 30]
curves.sort(reverse=True, key=lambda x: x[0])

output = cropped_image.copy()

if len(curves) < 2:
    print("No se encontraron suficientes curvas.")
    exit()

print("\nCurvas más largas encontradas:")
centers = []

# Procesar las 2 curvas más largas
for i in range(2):
    length_px, cnt = curves[i]
    length_mm = round(length_px * factor_conversion, 2)
    cv2.drawContours(output, [cnt], -1, (255, 0, 255), 2)

    # Calcular centroide o usar centro del bounding box si m00 = 0
    M = cv2.moments(cnt)
    if M["m00"] != 0:
        cx = int(M["m10"] / M["m00"])
        cy = int(M["m01"] / M["m00"])
    else:
        x, y, w, h = cv2.boundingRect(cnt)
        cx = x + w // 2
        cy = y + h // 2

    centers.append((cx, cy))
    cv2.circle(output, (cx, cy), 5, (0, 255, 255), -1)

    print(f"Curva {i+1}: {round(length_px)} px ({length_mm} mm)")

# Dibujar línea amarilla entre centros
if len(centers) == 2:
    pt1, pt2 = centers
    cv2.line(output, pt1, pt2, (0, 255, 255), 2)
    dist_px = np.linalg.norm(np.array(pt1) - np.array(pt2))
    dist_mm = round(dist_px * factor_conversion, 2)
    midpoint = tuple(((np.array(pt1) + np.array(pt2)) // 2).astype(int))
    cv2.putText(output, f"{dist_mm} mm", midpoint, cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 2)
    print(f"Distancia entre centros: {round(dist_px)} px ({dist_mm} mm)")
else:
    print("No se pudieron calcular los dos centros.")

# Mostrar resultado final
cv2.imshow("Curvas y línea en ROI", output)
cv2.waitKey(0)
cv2.destroyAllWindows()
