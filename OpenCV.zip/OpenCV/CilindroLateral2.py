import cv2
import numpy as np

# Factores
factor_conversion = 41 / 78  # mm/px

def es_horizontal(x1, y1, x2, y2, umbral_angulo=10):
    angle = np.degrees(np.arctan2(y2 - y1, x2 - x1))
    return abs(angle) < umbral_angulo or abs(angle) > (180 - umbral_angulo)

def es_vertical(x1, y1, x2, y2, umbral_angulo=10):
    angle = np.degrees(np.arctan2(y2 - y1, x2 - x1))
    return abs(abs(angle) - 90) < umbral_angulo

def unir_lineas_similares(lineas, es_tipo, distancia_umbral=2):
    grupos = []
    for l in lineas:
        x1, y1, x2, y2 = l
        agregado = False
        for grupo in grupos:
            for g in grupo:
                if es_tipo(x1, y1, x2, y2) and (
                    np.linalg.norm([x1 - g[0], y1 - g[1]]) < distancia_umbral or
                    np.linalg.norm([x2 - g[2], y2 - g[3]]) < distancia_umbral
                ):
                    grupo.append((x1, y1, x2, y2))
                    agregado = True
                    break
            if agregado:
                break
        if not agregado:
            grupos.append([(x1, y1, x2, y2)])
    
    lineas_unidas = []
    for grupo in grupos:
        xs = [x1 for x1, _, x2, _ in grupo] + [x2 for _, _, x2, _ in grupo]
        ys = [y1 for _, y1, _, y2 in grupo] + [y2 for _, _, _, y2 in grupo]
        if es_tipo == es_horizontal:
            y_prom = int(np.mean(ys))
            lineas_unidas.append((min(xs), y_prom, max(xs), y_prom))
        else:
            x_prom = int(np.mean(xs))
            lineas_unidas.append((x_prom, min(ys), x_prom, max(ys)))
    
    return lineas_unidas

def eliminar_lineas_duplicadas(lineas, umbral=15, es_tipo=None):
    finales = []
    for l in lineas:
        x1, y1, x2, y2 = l
        duplicada = False
        for lx1, ly1, lx2, ly2 in finales:
            if es_tipo == es_horizontal:
                misma_altura = abs(y1 - ly1) < umbral and abs(y2 - ly2) < umbral
                solapamiento = not (x2 < lx1 or x1 > lx2)
                if misma_altura and solapamiento:
                    duplicada = True
                    break
            elif es_tipo == es_vertical:
                misma_columna = abs(x1 - lx1) < umbral and abs(x2 - lx2) < umbral
                solapamiento = not (y2 < ly1 or y1 > ly2)
                if misma_columna and solapamiento:
                    duplicada = True
                    break
        if not duplicada:
            finales.append(l)
    return finales

# Cargar imagen y ROI
cap = cv2.VideoCapture(2)
if not cap.isOpened():
    print("No se pudo acceder a la cámara.")
    exit()

ret, frame = cap.read()
image = frame.copy()
clone = image.copy()
roi = None

def select_roi(event, x, y, flags, param):
    global roi
    if event == cv2.EVENT_LBUTTONDOWN:
        roi = [(x, y)]
    elif event == cv2.EVENT_LBUTTONUP:
        roi.append((x, y))
        cv2.rectangle(clone, roi[0], roi[1], (0, 255, 0), 2)
        cv2.imshow("Imagen", clone)

cv2.imshow("Imagen", image)
cv2.setMouseCallback("Imagen", select_roi)
cv2.waitKey(0)
cv2.destroyAllWindows()

if roi and len(roi) == 2:
    x1, y1 = roi[0]
    x2, y2 = roi[1]
    cropped = image[min(y1,y2):max(y1,y2), min(x1,x2):max(x1,x2)]
else:
    cropped = image.copy()

gray = cv2.cvtColor(cropped, cv2.COLOR_BGR2GRAY)
blurred = cv2.GaussianBlur(gray, (7, 7), 0)
edges = cv2.Canny(blurred, 30, 100)

lineas = cv2.HoughLinesP(edges, 1, np.pi / 180, threshold=7, minLineLength=10, maxLineGap=15)
height, width = cropped.shape[:2]
border_margin = 10

horizontales = []
verticales = []

if lineas is not None:
    for line in lineas:
        x1, y1, x2, y2 = line[0]
        if min(x1, x2) < border_margin or max(x1, x2) > width - border_margin:
            continue
        if min(y1, y2) < border_margin or max(y1, y2) > height - border_margin:
            continue
        if es_horizontal(x1, y1, x2, y2):
            horizontales.append((x1, y1, x2, y2))
        elif es_vertical(x1, y1, x2, y2):
            verticales.append((x1, y1, x2, y2))

# Unir y eliminar duplicadas
lineas_horizontales = unir_lineas_similares(horizontales, es_horizontal)
lineas_horizontales = eliminar_lineas_duplicadas(lineas_horizontales, umbral=5, es_tipo=es_horizontal)

lineas_verticales = unir_lineas_similares(verticales, es_vertical)
lineas_verticales = eliminar_lineas_duplicadas(lineas_verticales, umbral=5, es_tipo=es_vertical)

# Seleccionar 2 horizontales y 4 verticales
lineas_horizontales = sorted(lineas_horizontales, key=lambda l: l[1])[:2]
lineas_verticales = sorted(lineas_verticales, key=lambda l: l[0])[:4]

# Dibujar líneas
resultado = cropped.copy()
for x1, y1, x2, y2 in lineas_horizontales + lineas_verticales:
    cv2.line(resultado, (x1, y1), (x2, y2), (0, 255, 0), 2)

# Calcular distancia entre línea horizontal más alta y más baja
if len(lineas_horizontales) == 2:
    y_top = lineas_horizontales[0][1]
    y_bottom = lineas_horizontales[1][1]
    distancia_px = abs(y_bottom - y_top)
    distancia_mm = distancia_px * factor_conversion

    print(f"\n📐 Distancia entre líneas horizontales más alta y más baja:")
    print(f"   {distancia_px:.2f} px | {distancia_mm:.2f} mm")

    # Dibujar línea de medición sobre la imagen
    x_ref = int((lineas_horizontales[0][0] + lineas_horizontales[0][2]) / 2)
    cv2.line(resultado, (x_ref, y_top), (x_ref, y_bottom), (0, 0, 255), 2)
    cv2.putText(resultado, f"{distancia_mm:.1f} mm", (x_ref + 5, int((y_top + y_bottom)/2)),
                cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 255), 1)


# Reportar resultados
todas_las_lineas = lineas_horizontales + lineas_verticales
print(f"\n🔍 Total de líneas detectadas: {len(todas_las_lineas)}")
print("📏 Longitudes de líneas:")

for i, (x1, y1, x2, y2) in enumerate(todas_las_lineas, start=1):
    longitud_px = np.linalg.norm([x2 - x1, y2 - y1])
    longitud_mm = longitud_px * factor_conversion
    print(f"  Línea {i}: ({x1}, {y1}) -> ({x2}, {y2}) | {longitud_px:.2f} px | {longitud_mm:.2f} mm")


# Dibujar y reportar la línea 3 en naranja
if len(todas_las_lineas) >= 3:
    x1, y1, x2, y2 = todas_las_lineas[2]
    longitud_px = np.linalg.norm([x2 - x1, y2 - y1])
    longitud_mm = longitud_px * factor_conversion

    print(f"\n🟠 Línea 3: ({x1}, {y1}) -> ({x2}, {y2})")
    print(f"   Longitud: {longitud_px:.2f} px | {longitud_mm:.2f} mm")

    # Dibujar la línea en naranja
    cv2.line(resultado, (x1, y1), (x2, y2), (0, 140, 255), 2)
    mid_x = int((x1 + x2) / 2)
    mid_y = int((y1 + y2) / 2)
    cv2.putText(resultado, f"{longitud_mm:.1f} mm", (mid_x + 5, mid_y),
                cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 140, 255), 1)

# Dibujar y reportar la línea 4 en azul
if len(todas_las_lineas) >= 4:
    x1, y1, x2, y2 = todas_las_lineas[3]
    longitud_px = np.linalg.norm([x2 - x1, y2 - y1])
    longitud_mm = longitud_px * factor_conversion

    print(f"\n🔹 Línea 4: ({x1}, {y1}) -> ({x2}, {y2})")
    print(f"   Longitud: {longitud_px:.2f} px | {longitud_mm:.2f} mm")

    # Dibujar la línea en azul
    cv2.line(resultado, (x1, y1), (x2, y2), (255, 0, 0), 2)
    mid_x = int((x1 + x2) / 2)
    mid_y = int((y1 + y2) / 2)
    cv2.putText(resultado, f"{longitud_mm:.1f} mm", (mid_x + 5, mid_y),
                cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 0, 0), 1)

# Calcular y mostrar distancia entre línea 4 y línea 5
if len(todas_las_lineas) >= 5:
    x1_4, y1_4, x2_4, y2_4 = todas_las_lineas[3]
    x1_5, y1_5, x2_5, y2_5 = todas_las_lineas[4]

    # Elegimos un punto medio de cada línea para medir distancia
    mid_4 = ((x1_4 + x2_4) / 2, (y1_4 + y2_4) / 2)
    mid_5 = ((x1_5 + x2_5) / 2, (y1_5 + y2_5) / 2)

    distancia_entre_l4_y_l5_px = np.linalg.norm(np.array(mid_5) - np.array(mid_4))
    distancia_entre_l4_y_l5_mm = distancia_entre_l4_y_l5_px * factor_conversion

    print(f"\n🔵 Distancia entre línea 4 y línea 5:")
    print(f"   {distancia_entre_l4_y_l5_px:.2f} px | {distancia_entre_l4_y_l5_mm:.2f} mm")

    # Dibujar la línea de medición
    punto1 = tuple(map(int, mid_4))
    punto2 = tuple(map(int, mid_5))
    cv2.line(resultado, punto1, punto2, (200, 0, 200), 2)
    texto = f"{distancia_entre_l4_y_l5_mm:.1f} mm"
    pos_texto = (int((punto1[0] + punto2[0]) / 2 + 5), int((punto1[1] + punto2[1]) / 2-17))
    cv2.putText(resultado, texto, pos_texto, cv2.FONT_HERSHEY_SIMPLEX, 0.4, (200, 0, 200), 1)


# Mostrar resultado
cv2.imshow("Resultado final", resultado)
#cv2.imshow("Edges", edges)

cv2.waitKey(0)
cv2.destroyAllWindows() 