import cv2
import numpy as np
import json
import os
import math
from collections import Counter

def analizar_lateralProPen(
    roi_file="roi_lat_pen.json", 
    factor_conversion=20 / 46,
    n_fotos=10,
    mostrar=True,
    delay=500
):
    roi = None
    validity_results = []

    def select_roi(event, x, y, flags, param):
        nonlocal roi
        if event == cv2.EVENT_LBUTTONDOWN:
            roi = [(x, y)]
        elif event == cv2.EVENT_LBUTTONUP:
            roi.append((x, y))
            cv2.rectangle(frame_copy, roi[0], roi[1], (0, 255, 0), 2)
            cv2.imshow("Imagen", frame_copy)

    def load_or_select_roi(frame):
        nonlocal roi, frame_copy
        if os.path.exists(roi_file):
            with open(roi_file, "r") as f:
                roi = json.load(f)
                print(f"ROI cargado: {roi}")
        else:
            print("Selecciona un ROI (clic y arrastra)")
            frame_copy = frame.copy()
            cv2.imshow("Imagen", frame_copy)
            cv2.setMouseCallback("Imagen", select_roi)
            cv2.waitKey(0)
            cv2.destroyAllWindows()
            if roi and len(roi) == 2:
                with open(roi_file, "w") as f:
                    json.dump(roi, f)
                    print(f"ROI guardado en {roi_file}")
            else:
                print("No se seleccionó un ROI válido.")
                exit()

    cap = cv2.VideoCapture(1)
    if not cap.isOpened():
        print("No se pudo acceder a la cámara.")
        return False

    ret, frame = cap.read()
    if not ret:
        print("No se pudo capturar imagen inicial.")
        return False

    frame_copy = frame.copy()
    load_or_select_roi(frame)
    x1, y1 = roi[0]
    x2, y2 = roi[1]

    for photo_idx in range(n_fotos):
        ret, frame = cap.read()
        if not ret:
            print(f"No se pudo capturar la imagen {photo_idx+1}")
            validity_results.append(False)
            continue

        cropped_image = frame[y1:y2, x1:x2].copy()
        output = cropped_image.copy()

        gray = cv2.cvtColor(cropped_image, cv2.COLOR_BGR2GRAY)
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)
        edges = cv2.Canny(blurred, 50, 150)

        contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        curves = [(cv2.arcLength(c, False), c) for c in contours if cv2.arcLength(c, False) > 30]
        curves.sort(reverse=True, key=lambda x: x[0])

        print(f"\n📷 Foto {photo_idx+1}")
        valid = False
        centers = []

        if len(curves) >= 2:
            for i in range(2):
                length_px, cnt = curves[i]
                length_mm = round(length_px * factor_conversion, 2)
                cv2.drawContours(output, [cnt], -1, (255, 0, 255), 2)

                M = cv2.moments(cnt)
                if M["m00"] != 0:
                    cx = int(M["m10"] / M["m00"])
                    cy = int(M["m01"] / M["m00"])
                else:
                    x, y, w, h = cv2.boundingRect(cnt)
                    cx = x + w // 2
                    cy = y + h // 2

                centers.append((cx, cy))
                cv2.circle(output, (cx, cy), 5, (0, 255, 255), -1)
                print(f"Curva {i+1}: {round(length_px)} px ({length_mm} mm)")

            pt1, pt2 = centers
            cv2.line(output, pt1, pt2, (0, 255, 255), 2)
            dist_px = np.linalg.norm(np.array(pt1) - np.array(pt2))
            dist_mm = round(dist_px * factor_conversion, 2)
            midpoint = tuple(((np.array(pt1) + np.array(pt2)) // 2).astype(int))
            cv2.putText(output, f"{dist_mm} mm", midpoint, cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 2)
            print(f"Distancia entre centros: {round(dist_px)} px ({dist_mm} mm)")

            if 19 <= dist_mm <= 21:
                valid = True
                print("✅ Foto válida")
            else:
                print("❌ Foto NO válida - fuera de rango")
        else:
            print("❌ No se encontraron suficientes curvas.")

        validity_results.append(valid)

        if mostrar:
            cv2.imshow(f"Foto {photo_idx+1}", output)
            cv2.waitKey(delay)
            cv2.destroyWindow(f"Foto {photo_idx+1}")

    cap.release()
    cv2.destroyAllWindows()

    final_validity = Counter(validity_results).most_common(1)[0][0]
    print("\n📊 Resultado final:")
    print("✅ La pieza es VÁLIDA." if final_validity else "❌ La pieza NO es válida.")

    return final_validity
